<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Request;
use App\Core\Time;
use App\Core\View;
use App\Services\PengaturanService;
use App\Services\RekapService;

final class LaporanController
{
    public function rekapHtml(Request $req): void
    {
        $now = Time::now();
        $bulan = (int) $req->input('bulan', (int)$now->format('n'));
        $tahun = (int) $req->input('tahun', (int)$now->format('Y'));
        $pegawaiId = (int) $req->input('pegawai_id', 0);

        $svc = new RekapService();
        $cfg = (new PengaturanService())->getAktif();

        if ($pegawaiId > 0) {
            $data = $svc->rekapHarianPegawai($pegawaiId, $bulan, $tahun);
            View::render('laporan/detail_print', [
                'data' => $data,
                'cfg' => $cfg,
                'cetak_pada' => $now->format('d-m-Y H:i'),
            ]);
        } else {
            $data = $svc->rekapBulanan($bulan, $tahun);
            View::render('laporan/rekap_print', [
                'data' => $data,
                'cfg' => $cfg,
                'cetak_pada' => $now->format('d-m-Y H:i'),
            ]);
        }
    }
}
