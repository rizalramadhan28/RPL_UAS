<?php
$d = $data;
?><!doctype html>
<html lang="id"><head><meta charset="utf-8">
<title>Laporan Rekap <?= str_pad((string)$d['bulan'],2,'0',STR_PAD_LEFT) ?>-<?= (int)$d['tahun'] ?></title>
<style>
  body { font-family: Arial, sans-serif; font-size: 12px; color: #000; }
  h1 { text-align:center; font-size: 18px; margin: 0; }
  h3 { text-align:center; margin: 0 0 4px; font-size: 14px; }
  table { border-collapse: collapse; width: 100%; margin-top: 12px; }
  th, td { border: 1px solid #000; padding: 6px; }
  th { background:#eee; }
  .footer { margin-top:24px; display:flex; justify-content:space-between; }
  @media print { .noprint { display: none; } }
  .noprint { margin: 8px 0; }
</style></head><body>

<div class="noprint">
  <button onclick="window.print()">Cetak</button>
  <span style="margin-left:12px;">Gunakan menu <em>Save as PDF</em> peramban untuk menyimpan PDF.</span>
</div>

<h1>Laporan Rekap Kehadiran</h1>
<h3>Pemerintah <?= e($cfg['nama_desa'] ?? 'Desa Wadas') ?></h3>
<p style="text-align:center;margin:0;">
  Periode: <?= str_pad((string)$d['bulan'],2,'0',STR_PAD_LEFT) ?>/<?= (int)$d['tahun'] ?>
  &nbsp;|&nbsp; Total Hari Kerja: <?= (int)$d['total_hari_kerja'] ?>
  &nbsp;|&nbsp; Tanggal Cetak: <?= e($cetak_pada) ?>
</p>

<table>
  <thead><tr>
    <th>No</th><th>Nama</th><th>Jabatan</th>
    <th>Hadir</th><th>Terlambat</th><th>Izin</th><th>Sakit</th><th>Alpha</th>
    <th>Total Hari Kerja</th>
  </tr></thead>
  <tbody>
    <?php foreach ($d['rows'] as $i => $r): ?>
      <tr>
        <td><?= $i+1 ?></td>
        <td><?= e($r['nama']) ?></td>
        <td><?= e($r['jabatan']) ?></td>
        <td><?= (int)$r['Hadir'] ?></td>
        <td><?= (int)$r['Terlambat'] ?></td>
        <td><?= (int)$r['Izin'] ?></td>
        <td><?= (int)$r['Sakit'] ?></td>
        <td><?= (int)$r['Alpha'] ?></td>
        <td><?= (int)$d['total_hari_kerja'] ?></td>
      </tr>
    <?php endforeach; ?>
    <?php if (empty($d['rows'])): ?>
      <tr><td colspan="9" style="text-align:center">Tidak ada data</td></tr>
    <?php endif; ?>
  </tbody>
</table>

<div class="footer">
  <div></div>
  <div style="text-align:center">
    <?= e($cfg['nama_desa'] ?? 'Desa Wadas') ?>, <?= e(date('d-m-Y')) ?><br>
    Mengetahui,<br><br><br><br>
    <strong>Kepala Desa</strong>
  </div>
</div>
</body></html>
