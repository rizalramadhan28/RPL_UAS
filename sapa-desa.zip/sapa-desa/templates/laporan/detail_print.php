<?php
$d = $data;
$p = $d['pegawai'];
?><!doctype html>
<html lang="id"><head><meta charset="utf-8">
<title>Detail Kehadiran <?= e($p['nama']) ?> <?= str_pad((string)$d['bulan'],2,'0',STR_PAD_LEFT) ?>-<?= (int)$d['tahun'] ?></title>
<style>
  body { font-family: Arial, sans-serif; font-size: 12px; }
  h1 { text-align:center; font-size: 18px; margin: 0; }
  h3 { text-align:center; margin: 0 0 4px; font-size: 14px; }
  table { border-collapse: collapse; width: 100%; margin-top: 12px; }
  th, td { border: 1px solid #000; padding: 5px 6px; }
  th { background:#eee; }
  @media print { .noprint { display: none; } }
  .noprint { margin: 8px 0; }
</style></head><body>

<div class="noprint">
  <button onclick="window.print()">Cetak</button>
</div>

<h1>Detail Kehadiran Pegawai</h1>
<h3>Pemerintah <?= e($cfg['nama_desa'] ?? 'Desa Wadas') ?></h3>
<p style="text-align:center;margin:0;">
  <?= e($p['nama']) ?> - <?= e($p['jabatan']) ?> <br>
  Periode: <?= str_pad((string)$d['bulan'],2,'0',STR_PAD_LEFT) ?>/<?= (int)$d['tahun'] ?>
  &nbsp;|&nbsp; Total Hari Kerja: <?= (int)$d['total_hari_kerja'] ?>
  &nbsp;|&nbsp; Cetak: <?= e($cetak_pada) ?>
</p>

<table>
  <thead><tr><th>No</th><th>Tanggal</th><th>Status</th><th>Masuk</th><th>Pulang</th><th>Keterangan</th></tr></thead>
  <tbody>
    <?php foreach ($d['rows'] as $i => $r): ?>
      <tr>
        <td><?= $i+1 ?></td>
        <td><?= e($r['tanggal']) ?></td>
        <td><?= e($r['status']) ?></td>
        <td><?= e($r['ts_masuk'] ?? '-') ?></td>
        <td><?= e($r['ts_pulang'] ?? '-') ?></td>
        <td><?= e($r['alasan_terlambat'] ?? $r['keterangan'] ?? '-') ?></td>
      </tr>
    <?php endforeach; ?>
    <?php if (empty($d['rows'])): ?>
      <tr><td colspan="6" style="text-align:center">Tidak ada data</td></tr>
    <?php endif; ?>
  </tbody>
</table>
</body></html>
